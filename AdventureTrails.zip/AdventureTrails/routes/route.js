var express= require('express')
var router = express.Router()
var path = require('path');
var dbmodule = require('../public/javascripts/dbmodule.js');
var session = require('express-session');


// //Exporting Data From Server to dbModule
// exports.names = function(data){
// 	console.log("data is :");
// 	console.log(data);
// 	contact = data[0].contact;
// 	dob = data[0].dob;
// 	address = data[0].address;
// 	firstName 	= data[0].firstname;
// 	lastName  	= data[0].lastName;
// 	userName  	= data[0].username;
// 	acBalance  	= data[0].balance;
// }


router.get('/', function(req, res) {
    console.log("Request For AdventureTrails Received");
	res.render('home', { title: 'AdventureTrails'});
});

// router.post('/login', function(req, res) {
// 	var username = req.body.username;
//     var pass = req.body.pass;
// 	//req.session.username = username;
// 	//console.log("Your session starts now"+req.session.username);
// 	dbmodule.authenticateUser(username, pass,res);
// });

router.get('/packages',function(req, res) {
	 console.log("Request For Packages Received");
res.render('packages', {title: 'Packages'})
});

router.get('/online_booking',function(req, res) {
	 console.log("Request For Bookings Page Received");
res.render('online_booking', {title: 'Book Your Packages'})
});

router.get('/media',function(req, res) {
	 console.log("Request For Media Received");
res.render('media', {title: 'Media Gallery'})
});

router.get('/contact_us',function(req, res) {
	 console.log("Request For Contact_us Received");
res.render('contact_us', {title: 'Contact Details'})
});

router.get('/login',function(req, res) {
	 console.log("Request For Login Received");
res.render('index', {title: 'Login to AdventreTrails'})
});

router.get('/admin',function(req, res) {
	 console.log("Request For Admin Received");
res.render('admin', {title: 'Booking Details'})
});

module.exports= router;


